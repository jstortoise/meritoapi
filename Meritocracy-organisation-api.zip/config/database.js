module.exports = {
    database: 'mongodb://localhost/meritocracyOrganization',
    secret: "your_key"
};